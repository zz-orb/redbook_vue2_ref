<template>
    <div class="containner">
      <router-view></router-view>
    </div>

  </template>
  <script>

  </script>
<style>
  .containner {
    width: 100%;
    height: 100%;
    background-image: url("../assets/mypic/dock2.jpeg");
    background-repeat: no-repeat;
    background-size:cover;
    
    position: relative;
  }
</style>